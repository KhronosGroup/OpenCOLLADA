/*
 * XML Type:  config_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.ConfigType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl;


/**
 * An XML config_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public interface ConfigType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConfigType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s728241FA4E565B07D1B39BC00883084B").resolveHandle("configtype12a3type");
    
    /**
     * Gets a List of "version" elements
     */
    java.util.List<de.netallied.xsd2Cppsax.saxfwl.VersionType> getVersionList();
    
    /**
     * Gets array of all "version" elements
     * @deprecated
     */
    de.netallied.xsd2Cppsax.saxfwl.VersionType[] getVersionArray();
    
    /**
     * Gets ith "version" element
     */
    de.netallied.xsd2Cppsax.saxfwl.VersionType getVersionArray(int i);
    
    /**
     * Returns number of "version" element
     */
    int sizeOfVersionArray();
    
    /**
     * Sets array of all "version" element
     */
    void setVersionArray(de.netallied.xsd2Cppsax.saxfwl.VersionType[] versionArray);
    
    /**
     * Sets ith "version" element
     */
    void setVersionArray(int i, de.netallied.xsd2Cppsax.saxfwl.VersionType version);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "version" element
     */
    de.netallied.xsd2Cppsax.saxfwl.VersionType insertNewVersion(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "version" element
     */
    de.netallied.xsd2Cppsax.saxfwl.VersionType addNewVersion();
    
    /**
     * Removes the ith "version" element
     */
    void removeVersion(int i);
    
    /**
     * Gets the "header" element
     */
    java.lang.String getHeader();
    
    /**
     * Gets (as xml) the "header" element
     */
    org.apache.xmlbeans.XmlString xgetHeader();
    
    /**
     * Sets the "header" element
     */
    void setHeader(java.lang.String header);
    
    /**
     * Sets (as xml) the "header" element
     */
    void xsetHeader(org.apache.xmlbeans.XmlString header);
    
    /**
     * Gets the "namespace" element
     */
    java.lang.String getNamespace();
    
    /**
     * Gets (as xml) the "namespace" element
     */
    org.apache.xmlbeans.XmlString xgetNamespace();
    
    /**
     * Sets the "namespace" element
     */
    void setNamespace(java.lang.String namespace);
    
    /**
     * Sets (as xml) the "namespace" element
     */
    void xsetNamespace(org.apache.xmlbeans.XmlString namespace);
    
    /**
     * Gets a List of "includeHeader" elements
     */
    java.util.List<java.lang.String> getIncludeHeaderList();
    
    /**
     * Gets array of all "includeHeader" elements
     * @deprecated
     */
    java.lang.String[] getIncludeHeaderArray();
    
    /**
     * Gets ith "includeHeader" element
     */
    java.lang.String getIncludeHeaderArray(int i);
    
    /**
     * Gets (as xml) a List of "includeHeader" elements
     */
    java.util.List<org.apache.xmlbeans.XmlString> xgetIncludeHeaderList();
    
    /**
     * Gets (as xml) array of all "includeHeader" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlString[] xgetIncludeHeaderArray();
    
    /**
     * Gets (as xml) ith "includeHeader" element
     */
    org.apache.xmlbeans.XmlString xgetIncludeHeaderArray(int i);
    
    /**
     * Returns number of "includeHeader" element
     */
    int sizeOfIncludeHeaderArray();
    
    /**
     * Sets array of all "includeHeader" element
     */
    void setIncludeHeaderArray(java.lang.String[] includeHeaderArray);
    
    /**
     * Sets ith "includeHeader" element
     */
    void setIncludeHeaderArray(int i, java.lang.String includeHeader);
    
    /**
     * Sets (as xml) array of all "includeHeader" element
     */
    void xsetIncludeHeaderArray(org.apache.xmlbeans.XmlString[] includeHeaderArray);
    
    /**
     * Sets (as xml) ith "includeHeader" element
     */
    void xsetIncludeHeaderArray(int i, org.apache.xmlbeans.XmlString includeHeader);
    
    /**
     * Inserts the value as the ith "includeHeader" element
     */
    void insertIncludeHeader(int i, java.lang.String includeHeader);
    
    /**
     * Appends the value as the last "includeHeader" element
     */
    void addIncludeHeader(java.lang.String includeHeader);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "includeHeader" element
     */
    org.apache.xmlbeans.XmlString insertNewIncludeHeader(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "includeHeader" element
     */
    org.apache.xmlbeans.XmlString addNewIncludeHeader();
    
    /**
     * Removes the ith "includeHeader" element
     */
    void removeIncludeHeader(int i);
    
    /**
     * Gets a List of "includeImpl" elements
     */
    java.util.List<java.lang.String> getIncludeImplList();
    
    /**
     * Gets array of all "includeImpl" elements
     * @deprecated
     */
    java.lang.String[] getIncludeImplArray();
    
    /**
     * Gets ith "includeImpl" element
     */
    java.lang.String getIncludeImplArray(int i);
    
    /**
     * Gets (as xml) a List of "includeImpl" elements
     */
    java.util.List<org.apache.xmlbeans.XmlString> xgetIncludeImplList();
    
    /**
     * Gets (as xml) array of all "includeImpl" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlString[] xgetIncludeImplArray();
    
    /**
     * Gets (as xml) ith "includeImpl" element
     */
    org.apache.xmlbeans.XmlString xgetIncludeImplArray(int i);
    
    /**
     * Returns number of "includeImpl" element
     */
    int sizeOfIncludeImplArray();
    
    /**
     * Sets array of all "includeImpl" element
     */
    void setIncludeImplArray(java.lang.String[] includeImplArray);
    
    /**
     * Sets ith "includeImpl" element
     */
    void setIncludeImplArray(int i, java.lang.String includeImpl);
    
    /**
     * Sets (as xml) array of all "includeImpl" element
     */
    void xsetIncludeImplArray(org.apache.xmlbeans.XmlString[] includeImplArray);
    
    /**
     * Sets (as xml) ith "includeImpl" element
     */
    void xsetIncludeImplArray(int i, org.apache.xmlbeans.XmlString includeImpl);
    
    /**
     * Inserts the value as the ith "includeImpl" element
     */
    void insertIncludeImpl(int i, java.lang.String includeImpl);
    
    /**
     * Appends the value as the last "includeImpl" element
     */
    void addIncludeImpl(java.lang.String includeImpl);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "includeImpl" element
     */
    org.apache.xmlbeans.XmlString insertNewIncludeImpl(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "includeImpl" element
     */
    org.apache.xmlbeans.XmlString addNewIncludeImpl();
    
    /**
     * Removes the ith "includeImpl" element
     */
    void removeIncludeImpl(int i);
    
    /**
     * Gets a List of "forwardDecl" elements
     */
    java.util.List<java.lang.String> getForwardDeclList();
    
    /**
     * Gets array of all "forwardDecl" elements
     * @deprecated
     */
    java.lang.String[] getForwardDeclArray();
    
    /**
     * Gets ith "forwardDecl" element
     */
    java.lang.String getForwardDeclArray(int i);
    
    /**
     * Gets (as xml) a List of "forwardDecl" elements
     */
    java.util.List<org.apache.xmlbeans.XmlString> xgetForwardDeclList();
    
    /**
     * Gets (as xml) array of all "forwardDecl" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlString[] xgetForwardDeclArray();
    
    /**
     * Gets (as xml) ith "forwardDecl" element
     */
    org.apache.xmlbeans.XmlString xgetForwardDeclArray(int i);
    
    /**
     * Returns number of "forwardDecl" element
     */
    int sizeOfForwardDeclArray();
    
    /**
     * Sets array of all "forwardDecl" element
     */
    void setForwardDeclArray(java.lang.String[] forwardDeclArray);
    
    /**
     * Sets ith "forwardDecl" element
     */
    void setForwardDeclArray(int i, java.lang.String forwardDecl);
    
    /**
     * Sets (as xml) array of all "forwardDecl" element
     */
    void xsetForwardDeclArray(org.apache.xmlbeans.XmlString[] forwardDeclArray);
    
    /**
     * Sets (as xml) ith "forwardDecl" element
     */
    void xsetForwardDeclArray(int i, org.apache.xmlbeans.XmlString forwardDecl);
    
    /**
     * Inserts the value as the ith "forwardDecl" element
     */
    void insertForwardDecl(int i, java.lang.String forwardDecl);
    
    /**
     * Appends the value as the last "forwardDecl" element
     */
    void addForwardDecl(java.lang.String forwardDecl);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "forwardDecl" element
     */
    org.apache.xmlbeans.XmlString insertNewForwardDecl(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "forwardDecl" element
     */
    org.apache.xmlbeans.XmlString addNewForwardDecl();
    
    /**
     * Removes the ith "forwardDecl" element
     */
    void removeForwardDecl(int i);
    
    /**
     * Gets the "outpathBaseInc" attribute
     */
    java.lang.String getOutpathBaseInc();
    
    /**
     * Gets (as xml) the "outpathBaseInc" attribute
     */
    org.apache.xmlbeans.XmlString xgetOutpathBaseInc();
    
    /**
     * True if has "outpathBaseInc" attribute
     */
    boolean isSetOutpathBaseInc();
    
    /**
     * Sets the "outpathBaseInc" attribute
     */
    void setOutpathBaseInc(java.lang.String outpathBaseInc);
    
    /**
     * Sets (as xml) the "outpathBaseInc" attribute
     */
    void xsetOutpathBaseInc(org.apache.xmlbeans.XmlString outpathBaseInc);
    
    /**
     * Unsets the "outpathBaseInc" attribute
     */
    void unsetOutpathBaseInc();
    
    /**
     * Gets the "outpathBaseSrc" attribute
     */
    java.lang.String getOutpathBaseSrc();
    
    /**
     * Gets (as xml) the "outpathBaseSrc" attribute
     */
    org.apache.xmlbeans.XmlString xgetOutpathBaseSrc();
    
    /**
     * True if has "outpathBaseSrc" attribute
     */
    boolean isSetOutpathBaseSrc();
    
    /**
     * Sets the "outpathBaseSrc" attribute
     */
    void setOutpathBaseSrc(java.lang.String outpathBaseSrc);
    
    /**
     * Sets (as xml) the "outpathBaseSrc" attribute
     */
    void xsetOutpathBaseSrc(org.apache.xmlbeans.XmlString outpathBaseSrc);
    
    /**
     * Unsets the "outpathBaseSrc" attribute
     */
    void unsetOutpathBaseSrc();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType newInstance() {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.saxfwl.ConfigType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.saxfwl.ConfigType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
