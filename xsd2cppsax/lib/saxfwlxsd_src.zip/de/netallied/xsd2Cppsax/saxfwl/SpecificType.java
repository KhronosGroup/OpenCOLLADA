/*
 * XML Type:  specific_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.SpecificType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl;


/**
 * An XML specific_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public interface SpecificType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SpecificType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s728241FA4E565B07D1B39BC00883084B").resolveHandle("specifictype5cf3type");
    
    /**
     * Gets a List of "parameter" elements
     */
    java.util.List<de.netallied.xsd2Cppsax.saxfwl.VariableType> getParameterList();
    
    /**
     * Gets array of all "parameter" elements
     * @deprecated
     */
    de.netallied.xsd2Cppsax.saxfwl.VariableType[] getParameterArray();
    
    /**
     * Gets ith "parameter" element
     */
    de.netallied.xsd2Cppsax.saxfwl.VariableType getParameterArray(int i);
    
    /**
     * Returns number of "parameter" element
     */
    int sizeOfParameterArray();
    
    /**
     * Sets array of all "parameter" element
     */
    void setParameterArray(de.netallied.xsd2Cppsax.saxfwl.VariableType[] parameterArray);
    
    /**
     * Sets ith "parameter" element
     */
    void setParameterArray(int i, de.netallied.xsd2Cppsax.saxfwl.VariableType parameter);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "parameter" element
     */
    de.netallied.xsd2Cppsax.saxfwl.VariableType insertNewParameter(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "parameter" element
     */
    de.netallied.xsd2Cppsax.saxfwl.VariableType addNewParameter();
    
    /**
     * Removes the ith "parameter" element
     */
    void removeParameter(int i);
    
    /**
     * Gets a List of "code_line" elements
     */
    java.util.List<java.lang.String> getCodeLineList();
    
    /**
     * Gets array of all "code_line" elements
     * @deprecated
     */
    java.lang.String[] getCodeLineArray();
    
    /**
     * Gets ith "code_line" element
     */
    java.lang.String getCodeLineArray(int i);
    
    /**
     * Gets (as xml) a List of "code_line" elements
     */
    java.util.List<org.apache.xmlbeans.XmlString> xgetCodeLineList();
    
    /**
     * Gets (as xml) array of all "code_line" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlString[] xgetCodeLineArray();
    
    /**
     * Gets (as xml) ith "code_line" element
     */
    org.apache.xmlbeans.XmlString xgetCodeLineArray(int i);
    
    /**
     * Returns number of "code_line" element
     */
    int sizeOfCodeLineArray();
    
    /**
     * Sets array of all "code_line" element
     */
    void setCodeLineArray(java.lang.String[] codeLineArray);
    
    /**
     * Sets ith "code_line" element
     */
    void setCodeLineArray(int i, java.lang.String codeLine);
    
    /**
     * Sets (as xml) array of all "code_line" element
     */
    void xsetCodeLineArray(org.apache.xmlbeans.XmlString[] codeLineArray);
    
    /**
     * Sets (as xml) ith "code_line" element
     */
    void xsetCodeLineArray(int i, org.apache.xmlbeans.XmlString codeLine);
    
    /**
     * Inserts the value as the ith "code_line" element
     */
    void insertCodeLine(int i, java.lang.String codeLine);
    
    /**
     * Appends the value as the last "code_line" element
     */
    void addCodeLine(java.lang.String codeLine);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "code_line" element
     */
    org.apache.xmlbeans.XmlString insertNewCodeLine(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "code_line" element
     */
    org.apache.xmlbeans.XmlString addNewCodeLine();
    
    /**
     * Removes the ith "code_line" element
     */
    void removeCodeLine(int i);
    
    /**
     * Gets the "name" attribute
     */
    java.lang.String getName();
    
    /**
     * Gets (as xml) the "name" attribute
     */
    org.apache.xmlbeans.XmlString xgetName();
    
    /**
     * True if has "name" attribute
     */
    boolean isSetName();
    
    /**
     * Sets the "name" attribute
     */
    void setName(java.lang.String name);
    
    /**
     * Sets (as xml) the "name" attribute
     */
    void xsetName(org.apache.xmlbeans.XmlString name);
    
    /**
     * Unsets the "name" attribute
     */
    void unsetName();
    
    /**
     * Gets the "version" attribute
     */
    int getVersion();
    
    /**
     * Gets (as xml) the "version" attribute
     */
    org.apache.xmlbeans.XmlInt xgetVersion();
    
    /**
     * Sets the "version" attribute
     */
    void setVersion(int version);
    
    /**
     * Sets (as xml) the "version" attribute
     */
    void xsetVersion(org.apache.xmlbeans.XmlInt version);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType newInstance() {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.saxfwl.SpecificType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.saxfwl.SpecificType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
