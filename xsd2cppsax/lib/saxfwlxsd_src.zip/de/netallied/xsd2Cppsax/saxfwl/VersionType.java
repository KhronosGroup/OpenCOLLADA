/*
 * XML Type:  version_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.VersionType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl;


/**
 * An XML version_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is an atomic type that is a restriction of de.netallied.xsd2Cppsax.saxfwl.VersionType.
 */
public interface VersionType extends org.apache.xmlbeans.XmlInt
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(VersionType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s728241FA4E565B07D1B39BC00883084B").resolveHandle("versiontype8ebftype");
    
    /**
     * Gets the "include" attribute
     */
    java.lang.String getInclude();
    
    /**
     * Gets (as xml) the "include" attribute
     */
    org.apache.xmlbeans.XmlString xgetInclude();
    
    /**
     * True if has "include" attribute
     */
    boolean isSetInclude();
    
    /**
     * Sets the "include" attribute
     */
    void setInclude(java.lang.String include);
    
    /**
     * Sets (as xml) the "include" attribute
     */
    void xsetInclude(org.apache.xmlbeans.XmlString include);
    
    /**
     * Unsets the "include" attribute
     */
    void unsetInclude();
    
    /**
     * Gets the "baseClass" attribute
     */
    java.lang.String getBaseClass();
    
    /**
     * Gets (as xml) the "baseClass" attribute
     */
    org.apache.xmlbeans.XmlString xgetBaseClass();
    
    /**
     * True if has "baseClass" attribute
     */
    boolean isSetBaseClass();
    
    /**
     * Sets the "baseClass" attribute
     */
    void setBaseClass(java.lang.String baseClass);
    
    /**
     * Sets (as xml) the "baseClass" attribute
     */
    void xsetBaseClass(org.apache.xmlbeans.XmlString baseClass);
    
    /**
     * Unsets the "baseClass" attribute
     */
    void unsetBaseClass();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType newInstance() {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.saxfwl.VersionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.saxfwl.VersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
