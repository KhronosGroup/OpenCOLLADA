/*
 * XML Type:  class_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.ClassType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * An XML class_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public class ClassTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.saxfwl.ClassType
{
    private static final long serialVersionUID = 1L;
    
    public ClassTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MEMBER$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "member");
    private static final javax.xml.namespace.QName CTOR$2 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "ctor");
    private static final javax.xml.namespace.QName METHOD$4 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "method");
    private static final javax.xml.namespace.QName NAME$6 = 
        new javax.xml.namespace.QName("", "name");
    private static final javax.xml.namespace.QName INCLUDE$8 = 
        new javax.xml.namespace.QName("", "include");
    private static final javax.xml.namespace.QName BASECLASS$10 = 
        new javax.xml.namespace.QName("", "baseClass");
    private static final javax.xml.namespace.QName BASEINCLUDE$12 = 
        new javax.xml.namespace.QName("", "baseInclude");
    
    
    /**
     * Gets the "member" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType getMember()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(MEMBER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "member" element
     */
    public void setMember(de.netallied.xsd2Cppsax.saxfwl.VariableType member)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(MEMBER$0, 0);
            if (target == null)
            {
                target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().add_element_user(MEMBER$0);
            }
            target.set(member);
        }
    }
    
    /**
     * Appends and returns a new empty "member" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType addNewMember()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().add_element_user(MEMBER$0);
            return target;
        }
    }
    
    /**
     * Gets the "ctor" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.CtorType getCtor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.CtorType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.CtorType)get_store().find_element_user(CTOR$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ctor" element
     */
    public void setCtor(de.netallied.xsd2Cppsax.saxfwl.CtorType ctor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.CtorType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.CtorType)get_store().find_element_user(CTOR$2, 0);
            if (target == null)
            {
                target = (de.netallied.xsd2Cppsax.saxfwl.CtorType)get_store().add_element_user(CTOR$2);
            }
            target.set(ctor);
        }
    }
    
    /**
     * Appends and returns a new empty "ctor" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.CtorType addNewCtor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.CtorType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.CtorType)get_store().add_element_user(CTOR$2);
            return target;
        }
    }
    
    /**
     * Gets a List of "method" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.saxfwl.MethodType> getMethodList()
    {
        final class MethodList extends java.util.AbstractList<de.netallied.xsd2Cppsax.saxfwl.MethodType>
        {
            public de.netallied.xsd2Cppsax.saxfwl.MethodType get(int i)
                { return ClassTypeImpl.this.getMethodArray(i); }
            
            public de.netallied.xsd2Cppsax.saxfwl.MethodType set(int i, de.netallied.xsd2Cppsax.saxfwl.MethodType o)
            {
                de.netallied.xsd2Cppsax.saxfwl.MethodType old = ClassTypeImpl.this.getMethodArray(i);
                ClassTypeImpl.this.setMethodArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.saxfwl.MethodType o)
                { ClassTypeImpl.this.insertNewMethod(i).set(o); }
            
            public de.netallied.xsd2Cppsax.saxfwl.MethodType remove(int i)
            {
                de.netallied.xsd2Cppsax.saxfwl.MethodType old = ClassTypeImpl.this.getMethodArray(i);
                ClassTypeImpl.this.removeMethod(i);
                return old;
            }
            
            public int size()
                { return ClassTypeImpl.this.sizeOfMethodArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new MethodList();
        }
    }
    
    /**
     * Gets array of all "method" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.saxfwl.MethodType[] getMethodArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.saxfwl.MethodType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.saxfwl.MethodType>();
            get_store().find_all_element_users(METHOD$4, targetList);
            de.netallied.xsd2Cppsax.saxfwl.MethodType[] result = new de.netallied.xsd2Cppsax.saxfwl.MethodType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "method" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.MethodType getMethodArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.MethodType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.MethodType)get_store().find_element_user(METHOD$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "method" element
     */
    public int sizeOfMethodArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(METHOD$4);
        }
    }
    
    /**
     * Sets array of all "method" element
     */
    public void setMethodArray(de.netallied.xsd2Cppsax.saxfwl.MethodType[] methodArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(methodArray, METHOD$4);
        }
    }
    
    /**
     * Sets ith "method" element
     */
    public void setMethodArray(int i, de.netallied.xsd2Cppsax.saxfwl.MethodType method)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.MethodType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.MethodType)get_store().find_element_user(METHOD$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(method);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "method" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.MethodType insertNewMethod(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.MethodType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.MethodType)get_store().insert_element_user(METHOD$4, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "method" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.MethodType addNewMethod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.MethodType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.MethodType)get_store().add_element_user(METHOD$4);
            return target;
        }
    }
    
    /**
     * Removes the ith "method" element
     */
    public void removeMethod(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(METHOD$4, i);
        }
    }
    
    /**
     * Gets the "name" attribute
     */
    public java.lang.String getName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(NAME$6);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "name" attribute
     */
    public org.apache.xmlbeans.XmlString xgetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(NAME$6);
            return target;
        }
    }
    
    /**
     * True if has "name" attribute
     */
    public boolean isSetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(NAME$6) != null;
        }
    }
    
    /**
     * Sets the "name" attribute
     */
    public void setName(java.lang.String name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(NAME$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(NAME$6);
            }
            target.setStringValue(name);
        }
    }
    
    /**
     * Sets (as xml) the "name" attribute
     */
    public void xsetName(org.apache.xmlbeans.XmlString name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(NAME$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(NAME$6);
            }
            target.set(name);
        }
    }
    
    /**
     * Unsets the "name" attribute
     */
    public void unsetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(NAME$6);
        }
    }
    
    /**
     * Gets the "include" attribute
     */
    public java.lang.String getInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INCLUDE$8);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "include" attribute
     */
    public org.apache.xmlbeans.XmlString xgetInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(INCLUDE$8);
            return target;
        }
    }
    
    /**
     * True if has "include" attribute
     */
    public boolean isSetInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(INCLUDE$8) != null;
        }
    }
    
    /**
     * Sets the "include" attribute
     */
    public void setInclude(java.lang.String include)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INCLUDE$8);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(INCLUDE$8);
            }
            target.setStringValue(include);
        }
    }
    
    /**
     * Sets (as xml) the "include" attribute
     */
    public void xsetInclude(org.apache.xmlbeans.XmlString include)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(INCLUDE$8);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(INCLUDE$8);
            }
            target.set(include);
        }
    }
    
    /**
     * Unsets the "include" attribute
     */
    public void unsetInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(INCLUDE$8);
        }
    }
    
    /**
     * Gets the "baseClass" attribute
     */
    public java.lang.String getBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(BASECLASS$10);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "baseClass" attribute
     */
    public org.apache.xmlbeans.XmlString xgetBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(BASECLASS$10);
            return target;
        }
    }
    
    /**
     * True if has "baseClass" attribute
     */
    public boolean isSetBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(BASECLASS$10) != null;
        }
    }
    
    /**
     * Sets the "baseClass" attribute
     */
    public void setBaseClass(java.lang.String baseClass)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(BASECLASS$10);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(BASECLASS$10);
            }
            target.setStringValue(baseClass);
        }
    }
    
    /**
     * Sets (as xml) the "baseClass" attribute
     */
    public void xsetBaseClass(org.apache.xmlbeans.XmlString baseClass)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(BASECLASS$10);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(BASECLASS$10);
            }
            target.set(baseClass);
        }
    }
    
    /**
     * Unsets the "baseClass" attribute
     */
    public void unsetBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(BASECLASS$10);
        }
    }
    
    /**
     * Gets the "baseInclude" attribute
     */
    public java.lang.String getBaseInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(BASEINCLUDE$12);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "baseInclude" attribute
     */
    public org.apache.xmlbeans.XmlString xgetBaseInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(BASEINCLUDE$12);
            return target;
        }
    }
    
    /**
     * True if has "baseInclude" attribute
     */
    public boolean isSetBaseInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(BASEINCLUDE$12) != null;
        }
    }
    
    /**
     * Sets the "baseInclude" attribute
     */
    public void setBaseInclude(java.lang.String baseInclude)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(BASEINCLUDE$12);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(BASEINCLUDE$12);
            }
            target.setStringValue(baseInclude);
        }
    }
    
    /**
     * Sets (as xml) the "baseInclude" attribute
     */
    public void xsetBaseInclude(org.apache.xmlbeans.XmlString baseInclude)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(BASEINCLUDE$12);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(BASEINCLUDE$12);
            }
            target.set(baseInclude);
        }
    }
    
    /**
     * Unsets the "baseInclude" attribute
     */
    public void unsetBaseInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(BASEINCLUDE$12);
        }
    }
}
