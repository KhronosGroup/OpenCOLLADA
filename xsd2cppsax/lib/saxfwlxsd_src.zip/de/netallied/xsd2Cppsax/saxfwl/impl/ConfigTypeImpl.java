/*
 * XML Type:  config_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.ConfigType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * An XML config_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public class ConfigTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.saxfwl.ConfigType
{
    private static final long serialVersionUID = 1L;
    
    public ConfigTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VERSION$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "version");
    private static final javax.xml.namespace.QName HEADER$2 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "header");
    private static final javax.xml.namespace.QName NAMESPACE$4 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "namespace");
    private static final javax.xml.namespace.QName INCLUDEHEADER$6 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "includeHeader");
    private static final javax.xml.namespace.QName INCLUDEIMPL$8 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "includeImpl");
    private static final javax.xml.namespace.QName FORWARDDECL$10 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "forwardDecl");
    private static final javax.xml.namespace.QName OUTPATHBASEINC$12 = 
        new javax.xml.namespace.QName("", "outpathBaseInc");
    private static final javax.xml.namespace.QName OUTPATHBASESRC$14 = 
        new javax.xml.namespace.QName("", "outpathBaseSrc");
    
    
    /**
     * Gets a List of "version" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.saxfwl.VersionType> getVersionList()
    {
        final class VersionList extends java.util.AbstractList<de.netallied.xsd2Cppsax.saxfwl.VersionType>
        {
            public de.netallied.xsd2Cppsax.saxfwl.VersionType get(int i)
                { return ConfigTypeImpl.this.getVersionArray(i); }
            
            public de.netallied.xsd2Cppsax.saxfwl.VersionType set(int i, de.netallied.xsd2Cppsax.saxfwl.VersionType o)
            {
                de.netallied.xsd2Cppsax.saxfwl.VersionType old = ConfigTypeImpl.this.getVersionArray(i);
                ConfigTypeImpl.this.setVersionArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.saxfwl.VersionType o)
                { ConfigTypeImpl.this.insertNewVersion(i).set(o); }
            
            public de.netallied.xsd2Cppsax.saxfwl.VersionType remove(int i)
            {
                de.netallied.xsd2Cppsax.saxfwl.VersionType old = ConfigTypeImpl.this.getVersionArray(i);
                ConfigTypeImpl.this.removeVersion(i);
                return old;
            }
            
            public int size()
                { return ConfigTypeImpl.this.sizeOfVersionArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new VersionList();
        }
    }
    
    /**
     * Gets array of all "version" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.saxfwl.VersionType[] getVersionArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.saxfwl.VersionType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.saxfwl.VersionType>();
            get_store().find_all_element_users(VERSION$0, targetList);
            de.netallied.xsd2Cppsax.saxfwl.VersionType[] result = new de.netallied.xsd2Cppsax.saxfwl.VersionType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "version" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VersionType getVersionArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VersionType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VersionType)get_store().find_element_user(VERSION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "version" element
     */
    public int sizeOfVersionArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VERSION$0);
        }
    }
    
    /**
     * Sets array of all "version" element
     */
    public void setVersionArray(de.netallied.xsd2Cppsax.saxfwl.VersionType[] versionArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(versionArray, VERSION$0);
        }
    }
    
    /**
     * Sets ith "version" element
     */
    public void setVersionArray(int i, de.netallied.xsd2Cppsax.saxfwl.VersionType version)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VersionType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VersionType)get_store().find_element_user(VERSION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(version);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "version" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VersionType insertNewVersion(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VersionType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VersionType)get_store().insert_element_user(VERSION$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "version" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VersionType addNewVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VersionType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VersionType)get_store().add_element_user(VERSION$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "version" element
     */
    public void removeVersion(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VERSION$0, i);
        }
    }
    
    /**
     * Gets the "header" element
     */
    public java.lang.String getHeader()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HEADER$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "header" element
     */
    public org.apache.xmlbeans.XmlString xgetHeader()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(HEADER$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "header" element
     */
    public void setHeader(java.lang.String header)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HEADER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(HEADER$2);
            }
            target.setStringValue(header);
        }
    }
    
    /**
     * Sets (as xml) the "header" element
     */
    public void xsetHeader(org.apache.xmlbeans.XmlString header)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(HEADER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(HEADER$2);
            }
            target.set(header);
        }
    }
    
    /**
     * Gets the "namespace" element
     */
    public java.lang.String getNamespace()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NAMESPACE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "namespace" element
     */
    public org.apache.xmlbeans.XmlString xgetNamespace()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NAMESPACE$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "namespace" element
     */
    public void setNamespace(java.lang.String namespace)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NAMESPACE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NAMESPACE$4);
            }
            target.setStringValue(namespace);
        }
    }
    
    /**
     * Sets (as xml) the "namespace" element
     */
    public void xsetNamespace(org.apache.xmlbeans.XmlString namespace)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NAMESPACE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NAMESPACE$4);
            }
            target.set(namespace);
        }
    }
    
    /**
     * Gets a List of "includeHeader" elements
     */
    public java.util.List<java.lang.String> getIncludeHeaderList()
    {
        final class IncludeHeaderList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return ConfigTypeImpl.this.getIncludeHeaderArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = ConfigTypeImpl.this.getIncludeHeaderArray(i);
                ConfigTypeImpl.this.setIncludeHeaderArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { ConfigTypeImpl.this.insertIncludeHeader(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = ConfigTypeImpl.this.getIncludeHeaderArray(i);
                ConfigTypeImpl.this.removeIncludeHeader(i);
                return old;
            }
            
            public int size()
                { return ConfigTypeImpl.this.sizeOfIncludeHeaderArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new IncludeHeaderList();
        }
    }
    
    /**
     * Gets array of all "includeHeader" elements
     * @deprecated
     */
    public java.lang.String[] getIncludeHeaderArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(INCLUDEHEADER$6, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "includeHeader" element
     */
    public java.lang.String getIncludeHeaderArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCLUDEHEADER$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "includeHeader" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlString> xgetIncludeHeaderList()
    {
        final class IncludeHeaderList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
        {
            public org.apache.xmlbeans.XmlString get(int i)
                { return ConfigTypeImpl.this.xgetIncludeHeaderArray(i); }
            
            public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
            {
                org.apache.xmlbeans.XmlString old = ConfigTypeImpl.this.xgetIncludeHeaderArray(i);
                ConfigTypeImpl.this.xsetIncludeHeaderArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlString o)
                { ConfigTypeImpl.this.insertNewIncludeHeader(i).set(o); }
            
            public org.apache.xmlbeans.XmlString remove(int i)
            {
                org.apache.xmlbeans.XmlString old = ConfigTypeImpl.this.xgetIncludeHeaderArray(i);
                ConfigTypeImpl.this.removeIncludeHeader(i);
                return old;
            }
            
            public int size()
                { return ConfigTypeImpl.this.sizeOfIncludeHeaderArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new IncludeHeaderList();
        }
    }
    
    /**
     * Gets array of all "includeHeader" elements
     * @deprecated
     */
    public org.apache.xmlbeans.XmlString[] xgetIncludeHeaderArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(INCLUDEHEADER$6, targetList);
            org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "includeHeader" element
     */
    public org.apache.xmlbeans.XmlString xgetIncludeHeaderArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INCLUDEHEADER$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlString)target;
        }
    }
    
    /**
     * Returns number of "includeHeader" element
     */
    public int sizeOfIncludeHeaderArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INCLUDEHEADER$6);
        }
    }
    
    /**
     * Sets array of all "includeHeader" element
     */
    public void setIncludeHeaderArray(java.lang.String[] includeHeaderArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(includeHeaderArray, INCLUDEHEADER$6);
        }
    }
    
    /**
     * Sets ith "includeHeader" element
     */
    public void setIncludeHeaderArray(int i, java.lang.String includeHeader)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCLUDEHEADER$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(includeHeader);
        }
    }
    
    /**
     * Sets (as xml) array of all "includeHeader" element
     */
    public void xsetIncludeHeaderArray(org.apache.xmlbeans.XmlString[]includeHeaderArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(includeHeaderArray, INCLUDEHEADER$6);
        }
    }
    
    /**
     * Sets (as xml) ith "includeHeader" element
     */
    public void xsetIncludeHeaderArray(int i, org.apache.xmlbeans.XmlString includeHeader)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INCLUDEHEADER$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(includeHeader);
        }
    }
    
    /**
     * Inserts the value as the ith "includeHeader" element
     */
    public void insertIncludeHeader(int i, java.lang.String includeHeader)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(INCLUDEHEADER$6, i);
            target.setStringValue(includeHeader);
        }
    }
    
    /**
     * Appends the value as the last "includeHeader" element
     */
    public void addIncludeHeader(java.lang.String includeHeader)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INCLUDEHEADER$6);
            target.setStringValue(includeHeader);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "includeHeader" element
     */
    public org.apache.xmlbeans.XmlString insertNewIncludeHeader(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(INCLUDEHEADER$6, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "includeHeader" element
     */
    public org.apache.xmlbeans.XmlString addNewIncludeHeader()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INCLUDEHEADER$6);
            return target;
        }
    }
    
    /**
     * Removes the ith "includeHeader" element
     */
    public void removeIncludeHeader(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INCLUDEHEADER$6, i);
        }
    }
    
    /**
     * Gets a List of "includeImpl" elements
     */
    public java.util.List<java.lang.String> getIncludeImplList()
    {
        final class IncludeImplList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return ConfigTypeImpl.this.getIncludeImplArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = ConfigTypeImpl.this.getIncludeImplArray(i);
                ConfigTypeImpl.this.setIncludeImplArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { ConfigTypeImpl.this.insertIncludeImpl(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = ConfigTypeImpl.this.getIncludeImplArray(i);
                ConfigTypeImpl.this.removeIncludeImpl(i);
                return old;
            }
            
            public int size()
                { return ConfigTypeImpl.this.sizeOfIncludeImplArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new IncludeImplList();
        }
    }
    
    /**
     * Gets array of all "includeImpl" elements
     * @deprecated
     */
    public java.lang.String[] getIncludeImplArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(INCLUDEIMPL$8, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "includeImpl" element
     */
    public java.lang.String getIncludeImplArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCLUDEIMPL$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "includeImpl" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlString> xgetIncludeImplList()
    {
        final class IncludeImplList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
        {
            public org.apache.xmlbeans.XmlString get(int i)
                { return ConfigTypeImpl.this.xgetIncludeImplArray(i); }
            
            public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
            {
                org.apache.xmlbeans.XmlString old = ConfigTypeImpl.this.xgetIncludeImplArray(i);
                ConfigTypeImpl.this.xsetIncludeImplArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlString o)
                { ConfigTypeImpl.this.insertNewIncludeImpl(i).set(o); }
            
            public org.apache.xmlbeans.XmlString remove(int i)
            {
                org.apache.xmlbeans.XmlString old = ConfigTypeImpl.this.xgetIncludeImplArray(i);
                ConfigTypeImpl.this.removeIncludeImpl(i);
                return old;
            }
            
            public int size()
                { return ConfigTypeImpl.this.sizeOfIncludeImplArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new IncludeImplList();
        }
    }
    
    /**
     * Gets array of all "includeImpl" elements
     * @deprecated
     */
    public org.apache.xmlbeans.XmlString[] xgetIncludeImplArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(INCLUDEIMPL$8, targetList);
            org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "includeImpl" element
     */
    public org.apache.xmlbeans.XmlString xgetIncludeImplArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INCLUDEIMPL$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlString)target;
        }
    }
    
    /**
     * Returns number of "includeImpl" element
     */
    public int sizeOfIncludeImplArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INCLUDEIMPL$8);
        }
    }
    
    /**
     * Sets array of all "includeImpl" element
     */
    public void setIncludeImplArray(java.lang.String[] includeImplArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(includeImplArray, INCLUDEIMPL$8);
        }
    }
    
    /**
     * Sets ith "includeImpl" element
     */
    public void setIncludeImplArray(int i, java.lang.String includeImpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCLUDEIMPL$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(includeImpl);
        }
    }
    
    /**
     * Sets (as xml) array of all "includeImpl" element
     */
    public void xsetIncludeImplArray(org.apache.xmlbeans.XmlString[]includeImplArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(includeImplArray, INCLUDEIMPL$8);
        }
    }
    
    /**
     * Sets (as xml) ith "includeImpl" element
     */
    public void xsetIncludeImplArray(int i, org.apache.xmlbeans.XmlString includeImpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INCLUDEIMPL$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(includeImpl);
        }
    }
    
    /**
     * Inserts the value as the ith "includeImpl" element
     */
    public void insertIncludeImpl(int i, java.lang.String includeImpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(INCLUDEIMPL$8, i);
            target.setStringValue(includeImpl);
        }
    }
    
    /**
     * Appends the value as the last "includeImpl" element
     */
    public void addIncludeImpl(java.lang.String includeImpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INCLUDEIMPL$8);
            target.setStringValue(includeImpl);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "includeImpl" element
     */
    public org.apache.xmlbeans.XmlString insertNewIncludeImpl(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(INCLUDEIMPL$8, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "includeImpl" element
     */
    public org.apache.xmlbeans.XmlString addNewIncludeImpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INCLUDEIMPL$8);
            return target;
        }
    }
    
    /**
     * Removes the ith "includeImpl" element
     */
    public void removeIncludeImpl(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INCLUDEIMPL$8, i);
        }
    }
    
    /**
     * Gets a List of "forwardDecl" elements
     */
    public java.util.List<java.lang.String> getForwardDeclList()
    {
        final class ForwardDeclList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return ConfigTypeImpl.this.getForwardDeclArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = ConfigTypeImpl.this.getForwardDeclArray(i);
                ConfigTypeImpl.this.setForwardDeclArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { ConfigTypeImpl.this.insertForwardDecl(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = ConfigTypeImpl.this.getForwardDeclArray(i);
                ConfigTypeImpl.this.removeForwardDecl(i);
                return old;
            }
            
            public int size()
                { return ConfigTypeImpl.this.sizeOfForwardDeclArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ForwardDeclList();
        }
    }
    
    /**
     * Gets array of all "forwardDecl" elements
     * @deprecated
     */
    public java.lang.String[] getForwardDeclArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(FORWARDDECL$10, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "forwardDecl" element
     */
    public java.lang.String getForwardDeclArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORWARDDECL$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "forwardDecl" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlString> xgetForwardDeclList()
    {
        final class ForwardDeclList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
        {
            public org.apache.xmlbeans.XmlString get(int i)
                { return ConfigTypeImpl.this.xgetForwardDeclArray(i); }
            
            public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
            {
                org.apache.xmlbeans.XmlString old = ConfigTypeImpl.this.xgetForwardDeclArray(i);
                ConfigTypeImpl.this.xsetForwardDeclArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlString o)
                { ConfigTypeImpl.this.insertNewForwardDecl(i).set(o); }
            
            public org.apache.xmlbeans.XmlString remove(int i)
            {
                org.apache.xmlbeans.XmlString old = ConfigTypeImpl.this.xgetForwardDeclArray(i);
                ConfigTypeImpl.this.removeForwardDecl(i);
                return old;
            }
            
            public int size()
                { return ConfigTypeImpl.this.sizeOfForwardDeclArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ForwardDeclList();
        }
    }
    
    /**
     * Gets array of all "forwardDecl" elements
     * @deprecated
     */
    public org.apache.xmlbeans.XmlString[] xgetForwardDeclArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(FORWARDDECL$10, targetList);
            org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "forwardDecl" element
     */
    public org.apache.xmlbeans.XmlString xgetForwardDeclArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORWARDDECL$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlString)target;
        }
    }
    
    /**
     * Returns number of "forwardDecl" element
     */
    public int sizeOfForwardDeclArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FORWARDDECL$10);
        }
    }
    
    /**
     * Sets array of all "forwardDecl" element
     */
    public void setForwardDeclArray(java.lang.String[] forwardDeclArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(forwardDeclArray, FORWARDDECL$10);
        }
    }
    
    /**
     * Sets ith "forwardDecl" element
     */
    public void setForwardDeclArray(int i, java.lang.String forwardDecl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORWARDDECL$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(forwardDecl);
        }
    }
    
    /**
     * Sets (as xml) array of all "forwardDecl" element
     */
    public void xsetForwardDeclArray(org.apache.xmlbeans.XmlString[]forwardDeclArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(forwardDeclArray, FORWARDDECL$10);
        }
    }
    
    /**
     * Sets (as xml) ith "forwardDecl" element
     */
    public void xsetForwardDeclArray(int i, org.apache.xmlbeans.XmlString forwardDecl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORWARDDECL$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(forwardDecl);
        }
    }
    
    /**
     * Inserts the value as the ith "forwardDecl" element
     */
    public void insertForwardDecl(int i, java.lang.String forwardDecl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(FORWARDDECL$10, i);
            target.setStringValue(forwardDecl);
        }
    }
    
    /**
     * Appends the value as the last "forwardDecl" element
     */
    public void addForwardDecl(java.lang.String forwardDecl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FORWARDDECL$10);
            target.setStringValue(forwardDecl);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "forwardDecl" element
     */
    public org.apache.xmlbeans.XmlString insertNewForwardDecl(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(FORWARDDECL$10, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "forwardDecl" element
     */
    public org.apache.xmlbeans.XmlString addNewForwardDecl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FORWARDDECL$10);
            return target;
        }
    }
    
    /**
     * Removes the ith "forwardDecl" element
     */
    public void removeForwardDecl(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FORWARDDECL$10, i);
        }
    }
    
    /**
     * Gets the "outpathBaseInc" attribute
     */
    public java.lang.String getOutpathBaseInc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTPATHBASEINC$12);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "outpathBaseInc" attribute
     */
    public org.apache.xmlbeans.XmlString xgetOutpathBaseInc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(OUTPATHBASEINC$12);
            return target;
        }
    }
    
    /**
     * True if has "outpathBaseInc" attribute
     */
    public boolean isSetOutpathBaseInc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(OUTPATHBASEINC$12) != null;
        }
    }
    
    /**
     * Sets the "outpathBaseInc" attribute
     */
    public void setOutpathBaseInc(java.lang.String outpathBaseInc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTPATHBASEINC$12);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(OUTPATHBASEINC$12);
            }
            target.setStringValue(outpathBaseInc);
        }
    }
    
    /**
     * Sets (as xml) the "outpathBaseInc" attribute
     */
    public void xsetOutpathBaseInc(org.apache.xmlbeans.XmlString outpathBaseInc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(OUTPATHBASEINC$12);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(OUTPATHBASEINC$12);
            }
            target.set(outpathBaseInc);
        }
    }
    
    /**
     * Unsets the "outpathBaseInc" attribute
     */
    public void unsetOutpathBaseInc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(OUTPATHBASEINC$12);
        }
    }
    
    /**
     * Gets the "outpathBaseSrc" attribute
     */
    public java.lang.String getOutpathBaseSrc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTPATHBASESRC$14);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "outpathBaseSrc" attribute
     */
    public org.apache.xmlbeans.XmlString xgetOutpathBaseSrc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(OUTPATHBASESRC$14);
            return target;
        }
    }
    
    /**
     * True if has "outpathBaseSrc" attribute
     */
    public boolean isSetOutpathBaseSrc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(OUTPATHBASESRC$14) != null;
        }
    }
    
    /**
     * Sets the "outpathBaseSrc" attribute
     */
    public void setOutpathBaseSrc(java.lang.String outpathBaseSrc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTPATHBASESRC$14);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(OUTPATHBASESRC$14);
            }
            target.setStringValue(outpathBaseSrc);
        }
    }
    
    /**
     * Sets (as xml) the "outpathBaseSrc" attribute
     */
    public void xsetOutpathBaseSrc(org.apache.xmlbeans.XmlString outpathBaseSrc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(OUTPATHBASESRC$14);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(OUTPATHBASESRC$14);
            }
            target.set(outpathBaseSrc);
        }
    }
    
    /**
     * Unsets the "outpathBaseSrc" attribute
     */
    public void unsetOutpathBaseSrc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(OUTPATHBASESRC$14);
        }
    }
}
