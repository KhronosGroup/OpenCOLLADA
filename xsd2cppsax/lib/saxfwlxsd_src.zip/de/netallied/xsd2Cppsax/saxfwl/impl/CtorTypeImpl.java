/*
 * XML Type:  ctor_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.CtorType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * An XML ctor_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public class CtorTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.saxfwl.CtorType
{
    private static final long serialVersionUID = 1L;
    
    public CtorTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "parameter");
    private static final javax.xml.namespace.QName INITLIST$2 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "initlist");
    
    
    /**
     * Gets the "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType getParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(PARAMETER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "parameter" element
     */
    public void setParameter(de.netallied.xsd2Cppsax.saxfwl.VariableType parameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(PARAMETER$0, 0);
            if (target == null)
            {
                target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().add_element_user(PARAMETER$0);
            }
            target.set(parameter);
        }
    }
    
    /**
     * Appends and returns a new empty "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType addNewParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().add_element_user(PARAMETER$0);
            return target;
        }
    }
    
    /**
     * Gets a List of "initlist" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.saxfwl.InitlistType> getInitlistList()
    {
        final class InitlistList extends java.util.AbstractList<de.netallied.xsd2Cppsax.saxfwl.InitlistType>
        {
            public de.netallied.xsd2Cppsax.saxfwl.InitlistType get(int i)
                { return CtorTypeImpl.this.getInitlistArray(i); }
            
            public de.netallied.xsd2Cppsax.saxfwl.InitlistType set(int i, de.netallied.xsd2Cppsax.saxfwl.InitlistType o)
            {
                de.netallied.xsd2Cppsax.saxfwl.InitlistType old = CtorTypeImpl.this.getInitlistArray(i);
                CtorTypeImpl.this.setInitlistArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.saxfwl.InitlistType o)
                { CtorTypeImpl.this.insertNewInitlist(i).set(o); }
            
            public de.netallied.xsd2Cppsax.saxfwl.InitlistType remove(int i)
            {
                de.netallied.xsd2Cppsax.saxfwl.InitlistType old = CtorTypeImpl.this.getInitlistArray(i);
                CtorTypeImpl.this.removeInitlist(i);
                return old;
            }
            
            public int size()
                { return CtorTypeImpl.this.sizeOfInitlistArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new InitlistList();
        }
    }
    
    /**
     * Gets array of all "initlist" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.saxfwl.InitlistType[] getInitlistArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.saxfwl.InitlistType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.saxfwl.InitlistType>();
            get_store().find_all_element_users(INITLIST$2, targetList);
            de.netallied.xsd2Cppsax.saxfwl.InitlistType[] result = new de.netallied.xsd2Cppsax.saxfwl.InitlistType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "initlist" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.InitlistType getInitlistArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.InitlistType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.InitlistType)get_store().find_element_user(INITLIST$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "initlist" element
     */
    public int sizeOfInitlistArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INITLIST$2);
        }
    }
    
    /**
     * Sets array of all "initlist" element
     */
    public void setInitlistArray(de.netallied.xsd2Cppsax.saxfwl.InitlistType[] initlistArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(initlistArray, INITLIST$2);
        }
    }
    
    /**
     * Sets ith "initlist" element
     */
    public void setInitlistArray(int i, de.netallied.xsd2Cppsax.saxfwl.InitlistType initlist)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.InitlistType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.InitlistType)get_store().find_element_user(INITLIST$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(initlist);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "initlist" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.InitlistType insertNewInitlist(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.InitlistType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.InitlistType)get_store().insert_element_user(INITLIST$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "initlist" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.InitlistType addNewInitlist()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.InitlistType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.InitlistType)get_store().add_element_user(INITLIST$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "initlist" element
     */
    public void removeInitlist(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INITLIST$2, i);
        }
    }
}
