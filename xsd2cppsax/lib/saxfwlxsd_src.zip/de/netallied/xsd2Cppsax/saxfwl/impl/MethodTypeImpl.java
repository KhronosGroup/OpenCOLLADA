/*
 * XML Type:  method_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.MethodType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * An XML method_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public class MethodTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.saxfwl.MethodType
{
    private static final long serialVersionUID = 1L;
    
    public MethodTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "parameter");
    private static final javax.xml.namespace.QName SPECIFIC$2 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "specific");
    private static final javax.xml.namespace.QName NAME$4 = 
        new javax.xml.namespace.QName("", "name");
    
    
    /**
     * Gets a List of "parameter" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.saxfwl.VariableType> getParameterList()
    {
        final class ParameterList extends java.util.AbstractList<de.netallied.xsd2Cppsax.saxfwl.VariableType>
        {
            public de.netallied.xsd2Cppsax.saxfwl.VariableType get(int i)
                { return MethodTypeImpl.this.getParameterArray(i); }
            
            public de.netallied.xsd2Cppsax.saxfwl.VariableType set(int i, de.netallied.xsd2Cppsax.saxfwl.VariableType o)
            {
                de.netallied.xsd2Cppsax.saxfwl.VariableType old = MethodTypeImpl.this.getParameterArray(i);
                MethodTypeImpl.this.setParameterArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.saxfwl.VariableType o)
                { MethodTypeImpl.this.insertNewParameter(i).set(o); }
            
            public de.netallied.xsd2Cppsax.saxfwl.VariableType remove(int i)
            {
                de.netallied.xsd2Cppsax.saxfwl.VariableType old = MethodTypeImpl.this.getParameterArray(i);
                MethodTypeImpl.this.removeParameter(i);
                return old;
            }
            
            public int size()
                { return MethodTypeImpl.this.sizeOfParameterArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ParameterList();
        }
    }
    
    /**
     * Gets array of all "parameter" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType[] getParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.saxfwl.VariableType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.saxfwl.VariableType>();
            get_store().find_all_element_users(PARAMETER$0, targetList);
            de.netallied.xsd2Cppsax.saxfwl.VariableType[] result = new de.netallied.xsd2Cppsax.saxfwl.VariableType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType getParameterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(PARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "parameter" element
     */
    public int sizeOfParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PARAMETER$0);
        }
    }
    
    /**
     * Sets array of all "parameter" element
     */
    public void setParameterArray(de.netallied.xsd2Cppsax.saxfwl.VariableType[] parameterArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(parameterArray, PARAMETER$0);
        }
    }
    
    /**
     * Sets ith "parameter" element
     */
    public void setParameterArray(int i, de.netallied.xsd2Cppsax.saxfwl.VariableType parameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(PARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(parameter);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType insertNewParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().insert_element_user(PARAMETER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType addNewParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().add_element_user(PARAMETER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "parameter" element
     */
    public void removeParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PARAMETER$0, i);
        }
    }
    
    /**
     * Gets a List of "specific" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.saxfwl.SpecificType> getSpecificList()
    {
        final class SpecificList extends java.util.AbstractList<de.netallied.xsd2Cppsax.saxfwl.SpecificType>
        {
            public de.netallied.xsd2Cppsax.saxfwl.SpecificType get(int i)
                { return MethodTypeImpl.this.getSpecificArray(i); }
            
            public de.netallied.xsd2Cppsax.saxfwl.SpecificType set(int i, de.netallied.xsd2Cppsax.saxfwl.SpecificType o)
            {
                de.netallied.xsd2Cppsax.saxfwl.SpecificType old = MethodTypeImpl.this.getSpecificArray(i);
                MethodTypeImpl.this.setSpecificArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.saxfwl.SpecificType o)
                { MethodTypeImpl.this.insertNewSpecific(i).set(o); }
            
            public de.netallied.xsd2Cppsax.saxfwl.SpecificType remove(int i)
            {
                de.netallied.xsd2Cppsax.saxfwl.SpecificType old = MethodTypeImpl.this.getSpecificArray(i);
                MethodTypeImpl.this.removeSpecific(i);
                return old;
            }
            
            public int size()
                { return MethodTypeImpl.this.sizeOfSpecificArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SpecificList();
        }
    }
    
    /**
     * Gets array of all "specific" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.saxfwl.SpecificType[] getSpecificArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.saxfwl.SpecificType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.saxfwl.SpecificType>();
            get_store().find_all_element_users(SPECIFIC$2, targetList);
            de.netallied.xsd2Cppsax.saxfwl.SpecificType[] result = new de.netallied.xsd2Cppsax.saxfwl.SpecificType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "specific" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.SpecificType getSpecificArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.SpecificType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.SpecificType)get_store().find_element_user(SPECIFIC$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "specific" element
     */
    public int sizeOfSpecificArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SPECIFIC$2);
        }
    }
    
    /**
     * Sets array of all "specific" element
     */
    public void setSpecificArray(de.netallied.xsd2Cppsax.saxfwl.SpecificType[] specificArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(specificArray, SPECIFIC$2);
        }
    }
    
    /**
     * Sets ith "specific" element
     */
    public void setSpecificArray(int i, de.netallied.xsd2Cppsax.saxfwl.SpecificType specific)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.SpecificType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.SpecificType)get_store().find_element_user(SPECIFIC$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(specific);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "specific" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.SpecificType insertNewSpecific(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.SpecificType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.SpecificType)get_store().insert_element_user(SPECIFIC$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "specific" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.SpecificType addNewSpecific()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.SpecificType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.SpecificType)get_store().add_element_user(SPECIFIC$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "specific" element
     */
    public void removeSpecific(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SPECIFIC$2, i);
        }
    }
    
    /**
     * Gets the "name" attribute
     */
    public java.lang.String getName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(NAME$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "name" attribute
     */
    public org.apache.xmlbeans.XmlString xgetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(NAME$4);
            return target;
        }
    }
    
    /**
     * True if has "name" attribute
     */
    public boolean isSetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(NAME$4) != null;
        }
    }
    
    /**
     * Sets the "name" attribute
     */
    public void setName(java.lang.String name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(NAME$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(NAME$4);
            }
            target.setStringValue(name);
        }
    }
    
    /**
     * Sets (as xml) the "name" attribute
     */
    public void xsetName(org.apache.xmlbeans.XmlString name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(NAME$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(NAME$4);
            }
            target.set(name);
        }
    }
    
    /**
     * Unsets the "name" attribute
     */
    public void unsetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(NAME$4);
        }
    }
}
