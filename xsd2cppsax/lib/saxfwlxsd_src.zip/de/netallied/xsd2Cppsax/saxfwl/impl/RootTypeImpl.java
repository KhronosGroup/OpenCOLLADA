/*
 * XML Type:  root_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.RootType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * An XML root_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public class RootTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.saxfwl.RootType
{
    private static final long serialVersionUID = 1L;
    
    public RootTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONFIG$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "config");
    private static final javax.xml.namespace.QName CLASS1$2 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "class");
    
    
    /**
     * Gets the "config" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.ConfigType getConfig()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.ConfigType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.ConfigType)get_store().find_element_user(CONFIG$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "config" element
     */
    public void setConfig(de.netallied.xsd2Cppsax.saxfwl.ConfigType config)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.ConfigType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.ConfigType)get_store().find_element_user(CONFIG$0, 0);
            if (target == null)
            {
                target = (de.netallied.xsd2Cppsax.saxfwl.ConfigType)get_store().add_element_user(CONFIG$0);
            }
            target.set(config);
        }
    }
    
    /**
     * Appends and returns a new empty "config" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.ConfigType addNewConfig()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.ConfigType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.ConfigType)get_store().add_element_user(CONFIG$0);
            return target;
        }
    }
    
    /**
     * Gets a List of "class" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.saxfwl.ClassType> getClass1List()
    {
        final class Class1List extends java.util.AbstractList<de.netallied.xsd2Cppsax.saxfwl.ClassType>
        {
            public de.netallied.xsd2Cppsax.saxfwl.ClassType get(int i)
                { return RootTypeImpl.this.getClass1Array(i); }
            
            public de.netallied.xsd2Cppsax.saxfwl.ClassType set(int i, de.netallied.xsd2Cppsax.saxfwl.ClassType o)
            {
                de.netallied.xsd2Cppsax.saxfwl.ClassType old = RootTypeImpl.this.getClass1Array(i);
                RootTypeImpl.this.setClass1Array(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.saxfwl.ClassType o)
                { RootTypeImpl.this.insertNewClass1(i).set(o); }
            
            public de.netallied.xsd2Cppsax.saxfwl.ClassType remove(int i)
            {
                de.netallied.xsd2Cppsax.saxfwl.ClassType old = RootTypeImpl.this.getClass1Array(i);
                RootTypeImpl.this.removeClass1(i);
                return old;
            }
            
            public int size()
                { return RootTypeImpl.this.sizeOfClass1Array(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new Class1List();
        }
    }
    
    /**
     * Gets array of all "class" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.saxfwl.ClassType[] getClass1Array()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.saxfwl.ClassType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.saxfwl.ClassType>();
            get_store().find_all_element_users(CLASS1$2, targetList);
            de.netallied.xsd2Cppsax.saxfwl.ClassType[] result = new de.netallied.xsd2Cppsax.saxfwl.ClassType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "class" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.ClassType getClass1Array(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.ClassType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.ClassType)get_store().find_element_user(CLASS1$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "class" element
     */
    public int sizeOfClass1Array()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLASS1$2);
        }
    }
    
    /**
     * Sets array of all "class" element
     */
    public void setClass1Array(de.netallied.xsd2Cppsax.saxfwl.ClassType[] class1Array)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(class1Array, CLASS1$2);
        }
    }
    
    /**
     * Sets ith "class" element
     */
    public void setClass1Array(int i, de.netallied.xsd2Cppsax.saxfwl.ClassType class1)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.ClassType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.ClassType)get_store().find_element_user(CLASS1$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(class1);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "class" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.ClassType insertNewClass1(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.ClassType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.ClassType)get_store().insert_element_user(CLASS1$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "class" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.ClassType addNewClass1()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.ClassType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.ClassType)get_store().add_element_user(CLASS1$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "class" element
     */
    public void removeClass1(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLASS1$2, i);
        }
    }
}
