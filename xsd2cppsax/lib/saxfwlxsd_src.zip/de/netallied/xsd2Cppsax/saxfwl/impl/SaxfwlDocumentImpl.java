/*
 * An XML document type.
 * Localname: saxfwl
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.SaxfwlDocument
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * A document containing one saxfwl(@http://www.netallied.de/xsd2cppsax/saxfwl) element.
 *
 * This is a complex type.
 */
public class SaxfwlDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.saxfwl.SaxfwlDocument
{
    private static final long serialVersionUID = 1L;
    
    public SaxfwlDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SAXFWL$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "saxfwl");
    
    
    /**
     * Gets the "saxfwl" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.RootType getSaxfwl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.RootType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.RootType)get_store().find_element_user(SAXFWL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "saxfwl" element
     */
    public void setSaxfwl(de.netallied.xsd2Cppsax.saxfwl.RootType saxfwl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.RootType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.RootType)get_store().find_element_user(SAXFWL$0, 0);
            if (target == null)
            {
                target = (de.netallied.xsd2Cppsax.saxfwl.RootType)get_store().add_element_user(SAXFWL$0);
            }
            target.set(saxfwl);
        }
    }
    
    /**
     * Appends and returns a new empty "saxfwl" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.RootType addNewSaxfwl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.RootType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.RootType)get_store().add_element_user(SAXFWL$0);
            return target;
        }
    }
}
