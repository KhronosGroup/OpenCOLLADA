/*
 * XML Type:  specific_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.SpecificType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * An XML specific_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is a complex type.
 */
public class SpecificTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.saxfwl.SpecificType
{
    private static final long serialVersionUID = 1L;
    
    public SpecificTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "parameter");
    private static final javax.xml.namespace.QName CODELINE$2 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/saxfwl", "code_line");
    private static final javax.xml.namespace.QName NAME$4 = 
        new javax.xml.namespace.QName("", "name");
    private static final javax.xml.namespace.QName VERSION$6 = 
        new javax.xml.namespace.QName("", "version");
    
    
    /**
     * Gets a List of "parameter" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.saxfwl.VariableType> getParameterList()
    {
        final class ParameterList extends java.util.AbstractList<de.netallied.xsd2Cppsax.saxfwl.VariableType>
        {
            public de.netallied.xsd2Cppsax.saxfwl.VariableType get(int i)
                { return SpecificTypeImpl.this.getParameterArray(i); }
            
            public de.netallied.xsd2Cppsax.saxfwl.VariableType set(int i, de.netallied.xsd2Cppsax.saxfwl.VariableType o)
            {
                de.netallied.xsd2Cppsax.saxfwl.VariableType old = SpecificTypeImpl.this.getParameterArray(i);
                SpecificTypeImpl.this.setParameterArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.saxfwl.VariableType o)
                { SpecificTypeImpl.this.insertNewParameter(i).set(o); }
            
            public de.netallied.xsd2Cppsax.saxfwl.VariableType remove(int i)
            {
                de.netallied.xsd2Cppsax.saxfwl.VariableType old = SpecificTypeImpl.this.getParameterArray(i);
                SpecificTypeImpl.this.removeParameter(i);
                return old;
            }
            
            public int size()
                { return SpecificTypeImpl.this.sizeOfParameterArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ParameterList();
        }
    }
    
    /**
     * Gets array of all "parameter" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType[] getParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.saxfwl.VariableType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.saxfwl.VariableType>();
            get_store().find_all_element_users(PARAMETER$0, targetList);
            de.netallied.xsd2Cppsax.saxfwl.VariableType[] result = new de.netallied.xsd2Cppsax.saxfwl.VariableType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType getParameterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(PARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "parameter" element
     */
    public int sizeOfParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PARAMETER$0);
        }
    }
    
    /**
     * Sets array of all "parameter" element
     */
    public void setParameterArray(de.netallied.xsd2Cppsax.saxfwl.VariableType[] parameterArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(parameterArray, PARAMETER$0);
        }
    }
    
    /**
     * Sets ith "parameter" element
     */
    public void setParameterArray(int i, de.netallied.xsd2Cppsax.saxfwl.VariableType parameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().find_element_user(PARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(parameter);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType insertNewParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().insert_element_user(PARAMETER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "parameter" element
     */
    public de.netallied.xsd2Cppsax.saxfwl.VariableType addNewParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.saxfwl.VariableType target = null;
            target = (de.netallied.xsd2Cppsax.saxfwl.VariableType)get_store().add_element_user(PARAMETER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "parameter" element
     */
    public void removeParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PARAMETER$0, i);
        }
    }
    
    /**
     * Gets a List of "code_line" elements
     */
    public java.util.List<java.lang.String> getCodeLineList()
    {
        final class CodeLineList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return SpecificTypeImpl.this.getCodeLineArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = SpecificTypeImpl.this.getCodeLineArray(i);
                SpecificTypeImpl.this.setCodeLineArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { SpecificTypeImpl.this.insertCodeLine(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = SpecificTypeImpl.this.getCodeLineArray(i);
                SpecificTypeImpl.this.removeCodeLine(i);
                return old;
            }
            
            public int size()
                { return SpecificTypeImpl.this.sizeOfCodeLineArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CodeLineList();
        }
    }
    
    /**
     * Gets array of all "code_line" elements
     * @deprecated
     */
    public java.lang.String[] getCodeLineArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(CODELINE$2, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "code_line" element
     */
    public java.lang.String getCodeLineArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODELINE$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "code_line" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlString> xgetCodeLineList()
    {
        final class CodeLineList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
        {
            public org.apache.xmlbeans.XmlString get(int i)
                { return SpecificTypeImpl.this.xgetCodeLineArray(i); }
            
            public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
            {
                org.apache.xmlbeans.XmlString old = SpecificTypeImpl.this.xgetCodeLineArray(i);
                SpecificTypeImpl.this.xsetCodeLineArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlString o)
                { SpecificTypeImpl.this.insertNewCodeLine(i).set(o); }
            
            public org.apache.xmlbeans.XmlString remove(int i)
            {
                org.apache.xmlbeans.XmlString old = SpecificTypeImpl.this.xgetCodeLineArray(i);
                SpecificTypeImpl.this.removeCodeLine(i);
                return old;
            }
            
            public int size()
                { return SpecificTypeImpl.this.sizeOfCodeLineArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CodeLineList();
        }
    }
    
    /**
     * Gets array of all "code_line" elements
     * @deprecated
     */
    public org.apache.xmlbeans.XmlString[] xgetCodeLineArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(CODELINE$2, targetList);
            org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "code_line" element
     */
    public org.apache.xmlbeans.XmlString xgetCodeLineArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODELINE$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlString)target;
        }
    }
    
    /**
     * Returns number of "code_line" element
     */
    public int sizeOfCodeLineArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODELINE$2);
        }
    }
    
    /**
     * Sets array of all "code_line" element
     */
    public void setCodeLineArray(java.lang.String[] codeLineArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(codeLineArray, CODELINE$2);
        }
    }
    
    /**
     * Sets ith "code_line" element
     */
    public void setCodeLineArray(int i, java.lang.String codeLine)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODELINE$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(codeLine);
        }
    }
    
    /**
     * Sets (as xml) array of all "code_line" element
     */
    public void xsetCodeLineArray(org.apache.xmlbeans.XmlString[]codeLineArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(codeLineArray, CODELINE$2);
        }
    }
    
    /**
     * Sets (as xml) ith "code_line" element
     */
    public void xsetCodeLineArray(int i, org.apache.xmlbeans.XmlString codeLine)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CODELINE$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(codeLine);
        }
    }
    
    /**
     * Inserts the value as the ith "code_line" element
     */
    public void insertCodeLine(int i, java.lang.String codeLine)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(CODELINE$2, i);
            target.setStringValue(codeLine);
        }
    }
    
    /**
     * Appends the value as the last "code_line" element
     */
    public void addCodeLine(java.lang.String codeLine)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODELINE$2);
            target.setStringValue(codeLine);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "code_line" element
     */
    public org.apache.xmlbeans.XmlString insertNewCodeLine(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(CODELINE$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "code_line" element
     */
    public org.apache.xmlbeans.XmlString addNewCodeLine()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CODELINE$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "code_line" element
     */
    public void removeCodeLine(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODELINE$2, i);
        }
    }
    
    /**
     * Gets the "name" attribute
     */
    public java.lang.String getName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(NAME$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "name" attribute
     */
    public org.apache.xmlbeans.XmlString xgetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(NAME$4);
            return target;
        }
    }
    
    /**
     * True if has "name" attribute
     */
    public boolean isSetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(NAME$4) != null;
        }
    }
    
    /**
     * Sets the "name" attribute
     */
    public void setName(java.lang.String name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(NAME$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(NAME$4);
            }
            target.setStringValue(name);
        }
    }
    
    /**
     * Sets (as xml) the "name" attribute
     */
    public void xsetName(org.apache.xmlbeans.XmlString name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(NAME$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(NAME$4);
            }
            target.set(name);
        }
    }
    
    /**
     * Unsets the "name" attribute
     */
    public void unsetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(NAME$4);
        }
    }
    
    /**
     * Gets the "version" attribute
     */
    public int getVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSION$6);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "version" attribute
     */
    public org.apache.xmlbeans.XmlInt xgetVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_attribute_user(VERSION$6);
            return target;
        }
    }
    
    /**
     * Sets the "version" attribute
     */
    public void setVersion(int version)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSION$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSION$6);
            }
            target.setIntValue(version);
        }
    }
    
    /**
     * Sets (as xml) the "version" attribute
     */
    public void xsetVersion(org.apache.xmlbeans.XmlInt version)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_attribute_user(VERSION$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_attribute_user(VERSION$6);
            }
            target.set(version);
        }
    }
}
