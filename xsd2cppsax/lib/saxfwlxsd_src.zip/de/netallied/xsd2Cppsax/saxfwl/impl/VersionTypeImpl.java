/*
 * XML Type:  version_type
 * Namespace: http://www.netallied.de/xsd2cppsax/saxfwl
 * Java type: de.netallied.xsd2Cppsax.saxfwl.VersionType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.saxfwl.impl;
/**
 * An XML version_type(@http://www.netallied.de/xsd2cppsax/saxfwl).
 *
 * This is an atomic type that is a restriction of de.netallied.xsd2Cppsax.saxfwl.VersionType.
 */
public class VersionTypeImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements de.netallied.xsd2Cppsax.saxfwl.VersionType
{
    private static final long serialVersionUID = 1L;
    
    public VersionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, true);
    }
    
    protected VersionTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
    
    private static final javax.xml.namespace.QName INCLUDE$0 = 
        new javax.xml.namespace.QName("", "include");
    private static final javax.xml.namespace.QName BASECLASS$2 = 
        new javax.xml.namespace.QName("", "baseClass");
    
    
    /**
     * Gets the "include" attribute
     */
    public java.lang.String getInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INCLUDE$0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "include" attribute
     */
    public org.apache.xmlbeans.XmlString xgetInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(INCLUDE$0);
            return target;
        }
    }
    
    /**
     * True if has "include" attribute
     */
    public boolean isSetInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(INCLUDE$0) != null;
        }
    }
    
    /**
     * Sets the "include" attribute
     */
    public void setInclude(java.lang.String include)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INCLUDE$0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(INCLUDE$0);
            }
            target.setStringValue(include);
        }
    }
    
    /**
     * Sets (as xml) the "include" attribute
     */
    public void xsetInclude(org.apache.xmlbeans.XmlString include)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(INCLUDE$0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(INCLUDE$0);
            }
            target.set(include);
        }
    }
    
    /**
     * Unsets the "include" attribute
     */
    public void unsetInclude()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(INCLUDE$0);
        }
    }
    
    /**
     * Gets the "baseClass" attribute
     */
    public java.lang.String getBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(BASECLASS$2);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "baseClass" attribute
     */
    public org.apache.xmlbeans.XmlString xgetBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(BASECLASS$2);
            return target;
        }
    }
    
    /**
     * True if has "baseClass" attribute
     */
    public boolean isSetBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(BASECLASS$2) != null;
        }
    }
    
    /**
     * Sets the "baseClass" attribute
     */
    public void setBaseClass(java.lang.String baseClass)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(BASECLASS$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(BASECLASS$2);
            }
            target.setStringValue(baseClass);
        }
    }
    
    /**
     * Sets (as xml) the "baseClass" attribute
     */
    public void xsetBaseClass(org.apache.xmlbeans.XmlString baseClass)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(BASECLASS$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(BASECLASS$2);
            }
            target.set(baseClass);
        }
    }
    
    /**
     * Unsets the "baseClass" attribute
     */
    public void unsetBaseClass()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(BASECLASS$2);
        }
    }
}
