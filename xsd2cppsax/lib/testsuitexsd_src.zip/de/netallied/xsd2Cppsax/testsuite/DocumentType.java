/*
 * XML Type:  document_type
 * Namespace: http://www.netallied.de/xsd2cppsax/testsuite
 * Java type: de.netallied.xsd2Cppsax.testsuite.DocumentType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.testsuite;


/**
 * An XML document_type(@http://www.netallied.de/xsd2cppsax/testsuite).
 *
 * This is a complex type.
 */
public interface DocumentType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DocumentType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC94291712ADD5CFF575FA0273CD6038A").resolveHandle("documenttypefaadtype");
    
    /**
     * Gets a List of "expectedError" elements
     */
    java.util.List<java.lang.String> getExpectedErrorList();
    
    /**
     * Gets array of all "expectedError" elements
     * @deprecated
     */
    java.lang.String[] getExpectedErrorArray();
    
    /**
     * Gets ith "expectedError" element
     */
    java.lang.String getExpectedErrorArray(int i);
    
    /**
     * Gets (as xml) a List of "expectedError" elements
     */
    java.util.List<org.apache.xmlbeans.XmlString> xgetExpectedErrorList();
    
    /**
     * Gets (as xml) array of all "expectedError" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlString[] xgetExpectedErrorArray();
    
    /**
     * Gets (as xml) ith "expectedError" element
     */
    org.apache.xmlbeans.XmlString xgetExpectedErrorArray(int i);
    
    /**
     * Returns number of "expectedError" element
     */
    int sizeOfExpectedErrorArray();
    
    /**
     * Sets array of all "expectedError" element
     */
    void setExpectedErrorArray(java.lang.String[] expectedErrorArray);
    
    /**
     * Sets ith "expectedError" element
     */
    void setExpectedErrorArray(int i, java.lang.String expectedError);
    
    /**
     * Sets (as xml) array of all "expectedError" element
     */
    void xsetExpectedErrorArray(org.apache.xmlbeans.XmlString[] expectedErrorArray);
    
    /**
     * Sets (as xml) ith "expectedError" element
     */
    void xsetExpectedErrorArray(int i, org.apache.xmlbeans.XmlString expectedError);
    
    /**
     * Inserts the value as the ith "expectedError" element
     */
    void insertExpectedError(int i, java.lang.String expectedError);
    
    /**
     * Appends the value as the last "expectedError" element
     */
    void addExpectedError(java.lang.String expectedError);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "expectedError" element
     */
    org.apache.xmlbeans.XmlString insertNewExpectedError(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "expectedError" element
     */
    org.apache.xmlbeans.XmlString addNewExpectedError();
    
    /**
     * Removes the ith "expectedError" element
     */
    void removeExpectedError(int i);
    
    /**
     * Gets the "input" attribute
     */
    java.lang.String getInput();
    
    /**
     * Gets (as xml) the "input" attribute
     */
    org.apache.xmlbeans.XmlName xgetInput();
    
    /**
     * Sets the "input" attribute
     */
    void setInput(java.lang.String input);
    
    /**
     * Sets (as xml) the "input" attribute
     */
    void xsetInput(org.apache.xmlbeans.XmlName input);
    
    /**
     * Gets the "output" attribute
     */
    java.lang.String getOutput();
    
    /**
     * Gets (as xml) the "output" attribute
     */
    org.apache.xmlbeans.XmlName xgetOutput();
    
    /**
     * Sets the "output" attribute
     */
    void setOutput(java.lang.String output);
    
    /**
     * Sets (as xml) the "output" attribute
     */
    void xsetOutput(org.apache.xmlbeans.XmlName output);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType newInstance() {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.testsuite.DocumentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.testsuite.DocumentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
