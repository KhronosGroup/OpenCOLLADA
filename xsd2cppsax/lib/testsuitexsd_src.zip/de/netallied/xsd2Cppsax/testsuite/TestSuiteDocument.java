/*
 * An XML document type.
 * Localname: TestSuite
 * Namespace: http://www.netallied.de/xsd2cppsax/testsuite
 * Java type: de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.testsuite;


/**
 * A document containing one TestSuite(@http://www.netallied.de/xsd2cppsax/testsuite) element.
 *
 * This is a complex type.
 */
public interface TestSuiteDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TestSuiteDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC94291712ADD5CFF575FA0273CD6038A").resolveHandle("testsuitec8b5doctype");
    
    /**
     * Gets the "TestSuite" element
     */
    de.netallied.xsd2Cppsax.testsuite.TestSuiteType getTestSuite();
    
    /**
     * Sets the "TestSuite" element
     */
    void setTestSuite(de.netallied.xsd2Cppsax.testsuite.TestSuiteType testSuite);
    
    /**
     * Appends and returns a new empty "TestSuite" element
     */
    de.netallied.xsd2Cppsax.testsuite.TestSuiteType addNewTestSuite();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument newInstance() {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
