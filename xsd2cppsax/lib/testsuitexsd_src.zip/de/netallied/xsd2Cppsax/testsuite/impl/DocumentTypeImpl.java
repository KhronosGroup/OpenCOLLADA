/*
 * XML Type:  document_type
 * Namespace: http://www.netallied.de/xsd2cppsax/testsuite
 * Java type: de.netallied.xsd2Cppsax.testsuite.DocumentType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.testsuite.impl;
/**
 * An XML document_type(@http://www.netallied.de/xsd2cppsax/testsuite).
 *
 * This is a complex type.
 */
public class DocumentTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.testsuite.DocumentType
{
    private static final long serialVersionUID = 1L;
    
    public DocumentTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EXPECTEDERROR$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/testsuite", "expectedError");
    private static final javax.xml.namespace.QName INPUT$2 = 
        new javax.xml.namespace.QName("", "input");
    private static final javax.xml.namespace.QName OUTPUT$4 = 
        new javax.xml.namespace.QName("", "output");
    
    
    /**
     * Gets a List of "expectedError" elements
     */
    public java.util.List<java.lang.String> getExpectedErrorList()
    {
        final class ExpectedErrorList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return DocumentTypeImpl.this.getExpectedErrorArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = DocumentTypeImpl.this.getExpectedErrorArray(i);
                DocumentTypeImpl.this.setExpectedErrorArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { DocumentTypeImpl.this.insertExpectedError(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = DocumentTypeImpl.this.getExpectedErrorArray(i);
                DocumentTypeImpl.this.removeExpectedError(i);
                return old;
            }
            
            public int size()
                { return DocumentTypeImpl.this.sizeOfExpectedErrorArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ExpectedErrorList();
        }
    }
    
    /**
     * Gets array of all "expectedError" elements
     * @deprecated
     */
    public java.lang.String[] getExpectedErrorArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(EXPECTEDERROR$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "expectedError" element
     */
    public java.lang.String getExpectedErrorArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPECTEDERROR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "expectedError" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlString> xgetExpectedErrorList()
    {
        final class ExpectedErrorList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
        {
            public org.apache.xmlbeans.XmlString get(int i)
                { return DocumentTypeImpl.this.xgetExpectedErrorArray(i); }
            
            public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
            {
                org.apache.xmlbeans.XmlString old = DocumentTypeImpl.this.xgetExpectedErrorArray(i);
                DocumentTypeImpl.this.xsetExpectedErrorArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlString o)
                { DocumentTypeImpl.this.insertNewExpectedError(i).set(o); }
            
            public org.apache.xmlbeans.XmlString remove(int i)
            {
                org.apache.xmlbeans.XmlString old = DocumentTypeImpl.this.xgetExpectedErrorArray(i);
                DocumentTypeImpl.this.removeExpectedError(i);
                return old;
            }
            
            public int size()
                { return DocumentTypeImpl.this.sizeOfExpectedErrorArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ExpectedErrorList();
        }
    }
    
    /**
     * Gets array of all "expectedError" elements
     * @deprecated
     */
    public org.apache.xmlbeans.XmlString[] xgetExpectedErrorArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<org.apache.xmlbeans.XmlString> targetList = new java.util.ArrayList<org.apache.xmlbeans.XmlString>();
            get_store().find_all_element_users(EXPECTEDERROR$0, targetList);
            org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "expectedError" element
     */
    public org.apache.xmlbeans.XmlString xgetExpectedErrorArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXPECTEDERROR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlString)target;
        }
    }
    
    /**
     * Returns number of "expectedError" element
     */
    public int sizeOfExpectedErrorArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXPECTEDERROR$0);
        }
    }
    
    /**
     * Sets array of all "expectedError" element
     */
    public void setExpectedErrorArray(java.lang.String[] expectedErrorArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(expectedErrorArray, EXPECTEDERROR$0);
        }
    }
    
    /**
     * Sets ith "expectedError" element
     */
    public void setExpectedErrorArray(int i, java.lang.String expectedError)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPECTEDERROR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(expectedError);
        }
    }
    
    /**
     * Sets (as xml) array of all "expectedError" element
     */
    public void xsetExpectedErrorArray(org.apache.xmlbeans.XmlString[]expectedErrorArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(expectedErrorArray, EXPECTEDERROR$0);
        }
    }
    
    /**
     * Sets (as xml) ith "expectedError" element
     */
    public void xsetExpectedErrorArray(int i, org.apache.xmlbeans.XmlString expectedError)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXPECTEDERROR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(expectedError);
        }
    }
    
    /**
     * Inserts the value as the ith "expectedError" element
     */
    public void insertExpectedError(int i, java.lang.String expectedError)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(EXPECTEDERROR$0, i);
            target.setStringValue(expectedError);
        }
    }
    
    /**
     * Appends the value as the last "expectedError" element
     */
    public void addExpectedError(java.lang.String expectedError)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXPECTEDERROR$0);
            target.setStringValue(expectedError);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "expectedError" element
     */
    public org.apache.xmlbeans.XmlString insertNewExpectedError(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(EXPECTEDERROR$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "expectedError" element
     */
    public org.apache.xmlbeans.XmlString addNewExpectedError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXPECTEDERROR$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "expectedError" element
     */
    public void removeExpectedError(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXPECTEDERROR$0, i);
        }
    }
    
    /**
     * Gets the "input" attribute
     */
    public java.lang.String getInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INPUT$2);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "input" attribute
     */
    public org.apache.xmlbeans.XmlName xgetInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(INPUT$2);
            return target;
        }
    }
    
    /**
     * Sets the "input" attribute
     */
    public void setInput(java.lang.String input)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INPUT$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(INPUT$2);
            }
            target.setStringValue(input);
        }
    }
    
    /**
     * Sets (as xml) the "input" attribute
     */
    public void xsetInput(org.apache.xmlbeans.XmlName input)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(INPUT$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlName)get_store().add_attribute_user(INPUT$2);
            }
            target.set(input);
        }
    }
    
    /**
     * Gets the "output" attribute
     */
    public java.lang.String getOutput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTPUT$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "output" attribute
     */
    public org.apache.xmlbeans.XmlName xgetOutput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(OUTPUT$4);
            return target;
        }
    }
    
    /**
     * Sets the "output" attribute
     */
    public void setOutput(java.lang.String output)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTPUT$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(OUTPUT$4);
            }
            target.setStringValue(output);
        }
    }
    
    /**
     * Sets (as xml) the "output" attribute
     */
    public void xsetOutput(org.apache.xmlbeans.XmlName output)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(OUTPUT$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlName)get_store().add_attribute_user(OUTPUT$4);
            }
            target.set(output);
        }
    }
}
