/*
 * An XML document type.
 * Localname: TestSuite
 * Namespace: http://www.netallied.de/xsd2cppsax/testsuite
 * Java type: de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.testsuite.impl;
/**
 * A document containing one TestSuite(@http://www.netallied.de/xsd2cppsax/testsuite) element.
 *
 * This is a complex type.
 */
public class TestSuiteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.testsuite.TestSuiteDocument
{
    private static final long serialVersionUID = 1L;
    
    public TestSuiteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TESTSUITE$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/testsuite", "TestSuite");
    
    
    /**
     * Gets the "TestSuite" element
     */
    public de.netallied.xsd2Cppsax.testsuite.TestSuiteType getTestSuite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.TestSuiteType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.TestSuiteType)get_store().find_element_user(TESTSUITE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "TestSuite" element
     */
    public void setTestSuite(de.netallied.xsd2Cppsax.testsuite.TestSuiteType testSuite)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.TestSuiteType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.TestSuiteType)get_store().find_element_user(TESTSUITE$0, 0);
            if (target == null)
            {
                target = (de.netallied.xsd2Cppsax.testsuite.TestSuiteType)get_store().add_element_user(TESTSUITE$0);
            }
            target.set(testSuite);
        }
    }
    
    /**
     * Appends and returns a new empty "TestSuite" element
     */
    public de.netallied.xsd2Cppsax.testsuite.TestSuiteType addNewTestSuite()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.TestSuiteType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.TestSuiteType)get_store().add_element_user(TESTSUITE$0);
            return target;
        }
    }
}
