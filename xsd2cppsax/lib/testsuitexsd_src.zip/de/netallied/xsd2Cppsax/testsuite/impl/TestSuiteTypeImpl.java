/*
 * XML Type:  testSuite_type
 * Namespace: http://www.netallied.de/xsd2cppsax/testsuite
 * Java type: de.netallied.xsd2Cppsax.testsuite.TestSuiteType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.testsuite.impl;
/**
 * An XML testSuite_type(@http://www.netallied.de/xsd2cppsax/testsuite).
 *
 * This is a complex type.
 */
public class TestSuiteTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.testsuite.TestSuiteType
{
    private static final long serialVersionUID = 1L;
    
    public TestSuiteTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TEST$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/testsuite", "test");
    private static final javax.xml.namespace.QName OUTDIR$2 = 
        new javax.xml.namespace.QName("", "outDir");
    
    
    /**
     * Gets a List of "test" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.testsuite.TestType> getTestList()
    {
        final class TestList extends java.util.AbstractList<de.netallied.xsd2Cppsax.testsuite.TestType>
        {
            public de.netallied.xsd2Cppsax.testsuite.TestType get(int i)
                { return TestSuiteTypeImpl.this.getTestArray(i); }
            
            public de.netallied.xsd2Cppsax.testsuite.TestType set(int i, de.netallied.xsd2Cppsax.testsuite.TestType o)
            {
                de.netallied.xsd2Cppsax.testsuite.TestType old = TestSuiteTypeImpl.this.getTestArray(i);
                TestSuiteTypeImpl.this.setTestArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.testsuite.TestType o)
                { TestSuiteTypeImpl.this.insertNewTest(i).set(o); }
            
            public de.netallied.xsd2Cppsax.testsuite.TestType remove(int i)
            {
                de.netallied.xsd2Cppsax.testsuite.TestType old = TestSuiteTypeImpl.this.getTestArray(i);
                TestSuiteTypeImpl.this.removeTest(i);
                return old;
            }
            
            public int size()
                { return TestSuiteTypeImpl.this.sizeOfTestArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TestList();
        }
    }
    
    /**
     * Gets array of all "test" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.testsuite.TestType[] getTestArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.testsuite.TestType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.testsuite.TestType>();
            get_store().find_all_element_users(TEST$0, targetList);
            de.netallied.xsd2Cppsax.testsuite.TestType[] result = new de.netallied.xsd2Cppsax.testsuite.TestType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "test" element
     */
    public de.netallied.xsd2Cppsax.testsuite.TestType getTestArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.TestType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.TestType)get_store().find_element_user(TEST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "test" element
     */
    public int sizeOfTestArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TEST$0);
        }
    }
    
    /**
     * Sets array of all "test" element
     */
    public void setTestArray(de.netallied.xsd2Cppsax.testsuite.TestType[] testArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(testArray, TEST$0);
        }
    }
    
    /**
     * Sets ith "test" element
     */
    public void setTestArray(int i, de.netallied.xsd2Cppsax.testsuite.TestType test)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.TestType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.TestType)get_store().find_element_user(TEST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(test);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "test" element
     */
    public de.netallied.xsd2Cppsax.testsuite.TestType insertNewTest(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.TestType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.TestType)get_store().insert_element_user(TEST$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "test" element
     */
    public de.netallied.xsd2Cppsax.testsuite.TestType addNewTest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.TestType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.TestType)get_store().add_element_user(TEST$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "test" element
     */
    public void removeTest(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TEST$0, i);
        }
    }
    
    /**
     * Gets the "outDir" attribute
     */
    public java.lang.String getOutDir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTDIR$2);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "outDir" attribute
     */
    public org.apache.xmlbeans.XmlName xgetOutDir()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(OUTDIR$2);
            return target;
        }
    }
    
    /**
     * Sets the "outDir" attribute
     */
    public void setOutDir(java.lang.String outDir)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(OUTDIR$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(OUTDIR$2);
            }
            target.setStringValue(outDir);
        }
    }
    
    /**
     * Sets (as xml) the "outDir" attribute
     */
    public void xsetOutDir(org.apache.xmlbeans.XmlName outDir)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(OUTDIR$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlName)get_store().add_attribute_user(OUTDIR$2);
            }
            target.set(outDir);
        }
    }
}
