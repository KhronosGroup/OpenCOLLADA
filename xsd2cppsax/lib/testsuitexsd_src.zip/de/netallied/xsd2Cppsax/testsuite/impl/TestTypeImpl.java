/*
 * XML Type:  test_type
 * Namespace: http://www.netallied.de/xsd2cppsax/testsuite
 * Java type: de.netallied.xsd2Cppsax.testsuite.TestType
 *
 * Automatically generated - do not modify.
 */
package de.netallied.xsd2Cppsax.testsuite.impl;
/**
 * An XML test_type(@http://www.netallied.de/xsd2cppsax/testsuite).
 *
 * This is a complex type.
 */
public class TestTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements de.netallied.xsd2Cppsax.testsuite.TestType
{
    private static final long serialVersionUID = 1L;
    
    public TestTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOCUMENT$0 = 
        new javax.xml.namespace.QName("http://www.netallied.de/xsd2cppsax/testsuite", "document");
    private static final javax.xml.namespace.QName CONFIG$2 = 
        new javax.xml.namespace.QName("", "config");
    private static final javax.xml.namespace.QName INPUT$4 = 
        new javax.xml.namespace.QName("", "input");
    private static final javax.xml.namespace.QName ROOTELEMENT$6 = 
        new javax.xml.namespace.QName("", "rootElement");
    
    
    /**
     * Gets a List of "document" elements
     */
    public java.util.List<de.netallied.xsd2Cppsax.testsuite.DocumentType> getDocumentList()
    {
        final class DocumentList extends java.util.AbstractList<de.netallied.xsd2Cppsax.testsuite.DocumentType>
        {
            public de.netallied.xsd2Cppsax.testsuite.DocumentType get(int i)
                { return TestTypeImpl.this.getDocumentArray(i); }
            
            public de.netallied.xsd2Cppsax.testsuite.DocumentType set(int i, de.netallied.xsd2Cppsax.testsuite.DocumentType o)
            {
                de.netallied.xsd2Cppsax.testsuite.DocumentType old = TestTypeImpl.this.getDocumentArray(i);
                TestTypeImpl.this.setDocumentArray(i, o);
                return old;
            }
            
            public void add(int i, de.netallied.xsd2Cppsax.testsuite.DocumentType o)
                { TestTypeImpl.this.insertNewDocument(i).set(o); }
            
            public de.netallied.xsd2Cppsax.testsuite.DocumentType remove(int i)
            {
                de.netallied.xsd2Cppsax.testsuite.DocumentType old = TestTypeImpl.this.getDocumentArray(i);
                TestTypeImpl.this.removeDocument(i);
                return old;
            }
            
            public int size()
                { return TestTypeImpl.this.sizeOfDocumentArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new DocumentList();
        }
    }
    
    /**
     * Gets array of all "document" elements
     * @deprecated
     */
    public de.netallied.xsd2Cppsax.testsuite.DocumentType[] getDocumentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List<de.netallied.xsd2Cppsax.testsuite.DocumentType> targetList = new java.util.ArrayList<de.netallied.xsd2Cppsax.testsuite.DocumentType>();
            get_store().find_all_element_users(DOCUMENT$0, targetList);
            de.netallied.xsd2Cppsax.testsuite.DocumentType[] result = new de.netallied.xsd2Cppsax.testsuite.DocumentType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "document" element
     */
    public de.netallied.xsd2Cppsax.testsuite.DocumentType getDocumentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.DocumentType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.DocumentType)get_store().find_element_user(DOCUMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "document" element
     */
    public int sizeOfDocumentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENT$0);
        }
    }
    
    /**
     * Sets array of all "document" element
     */
    public void setDocumentArray(de.netallied.xsd2Cppsax.testsuite.DocumentType[] documentArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(documentArray, DOCUMENT$0);
        }
    }
    
    /**
     * Sets ith "document" element
     */
    public void setDocumentArray(int i, de.netallied.xsd2Cppsax.testsuite.DocumentType document)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.DocumentType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.DocumentType)get_store().find_element_user(DOCUMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(document);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "document" element
     */
    public de.netallied.xsd2Cppsax.testsuite.DocumentType insertNewDocument(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.DocumentType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.DocumentType)get_store().insert_element_user(DOCUMENT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "document" element
     */
    public de.netallied.xsd2Cppsax.testsuite.DocumentType addNewDocument()
    {
        synchronized (monitor())
        {
            check_orphaned();
            de.netallied.xsd2Cppsax.testsuite.DocumentType target = null;
            target = (de.netallied.xsd2Cppsax.testsuite.DocumentType)get_store().add_element_user(DOCUMENT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "document" element
     */
    public void removeDocument(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENT$0, i);
        }
    }
    
    /**
     * Gets the "config" attribute
     */
    public java.lang.String getConfig()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(CONFIG$2);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "config" attribute
     */
    public org.apache.xmlbeans.XmlName xgetConfig()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(CONFIG$2);
            return target;
        }
    }
    
    /**
     * Sets the "config" attribute
     */
    public void setConfig(java.lang.String config)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(CONFIG$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(CONFIG$2);
            }
            target.setStringValue(config);
        }
    }
    
    /**
     * Sets (as xml) the "config" attribute
     */
    public void xsetConfig(org.apache.xmlbeans.XmlName config)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(CONFIG$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlName)get_store().add_attribute_user(CONFIG$2);
            }
            target.set(config);
        }
    }
    
    /**
     * Gets the "input" attribute
     */
    public java.lang.String getInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INPUT$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "input" attribute
     */
    public org.apache.xmlbeans.XmlName xgetInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(INPUT$4);
            return target;
        }
    }
    
    /**
     * Sets the "input" attribute
     */
    public void setInput(java.lang.String input)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(INPUT$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(INPUT$4);
            }
            target.setStringValue(input);
        }
    }
    
    /**
     * Sets (as xml) the "input" attribute
     */
    public void xsetInput(org.apache.xmlbeans.XmlName input)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(INPUT$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlName)get_store().add_attribute_user(INPUT$4);
            }
            target.set(input);
        }
    }
    
    /**
     * Gets the "rootElement" attribute
     */
    public java.lang.String getRootElement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ROOTELEMENT$6);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "rootElement" attribute
     */
    public org.apache.xmlbeans.XmlName xgetRootElement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(ROOTELEMENT$6);
            return target;
        }
    }
    
    /**
     * Sets the "rootElement" attribute
     */
    public void setRootElement(java.lang.String rootElement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ROOTELEMENT$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ROOTELEMENT$6);
            }
            target.setStringValue(rootElement);
        }
    }
    
    /**
     * Sets (as xml) the "rootElement" attribute
     */
    public void xsetRootElement(org.apache.xmlbeans.XmlName rootElement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlName target = null;
            target = (org.apache.xmlbeans.XmlName)get_store().find_attribute_user(ROOTELEMENT$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlName)get_store().add_attribute_user(ROOTELEMENT$6);
            }
            target.set(rootElement);
        }
    }
}
